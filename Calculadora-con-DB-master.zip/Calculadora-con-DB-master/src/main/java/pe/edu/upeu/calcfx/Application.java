package pe.edu.upeu.calcfx;

public class Application {
    public static void main(String[] args) {
        CalcFxApplication.main(args);
    }
}
